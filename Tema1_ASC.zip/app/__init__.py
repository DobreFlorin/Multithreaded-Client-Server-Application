from flask import Flask
from app.data_ingestor import DataIngestor
from app.task_runner import ThreadPool
from queue import Queue
from  threading import Event
import os

webserver = Flask(__name__)
webserver.tasks_runner = ThreadPool()

for thread in webserver.tasks_runner.threads:
  thread.start()
#webserver.task_runner.start()


webserver.data_ingestor = DataIngestor("./nutrition_activity_obesity_usa_subset.csv")

webserver.job_counter = 0

from app import routes

webserver.results_folder = 'results'
if not os.path.exists(webserver.results_folder):
    os.makedirs(webserver.results_folder)

#try:
#if webserver.job_counter > 0:
#webserver.tasks_runner.job_queue.join()
#print("aici")
#except KeyboardInterrupt:
 # for _ in range(len(webserver.tasks_runner.threads)):
 #    webserver.tasks_runner.job_queue.put(None)
 #    webserver.tasks_runner.job_available.set()
 # for thread in webserver.tasks_runner.threads:
 #    thread.join()
